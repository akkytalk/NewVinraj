import React, { Fragment } from "react";

function ProcessParametersCf() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default ProcessParametersCf;
