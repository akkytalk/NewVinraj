import React, { Fragment } from "react";

function StockReportCf() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default StockReportCf;
