import React, { Fragment } from "react";

function ProductionPlanningVf() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default ProductionPlanningVf;
