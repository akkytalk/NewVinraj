import React, { Fragment } from "react";

function ProductionPlanningCf() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default ProductionPlanningCf;
