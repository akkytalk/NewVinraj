import React, { Fragment } from "react";

function ProductionReportCf() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default ProductionReportCf;
