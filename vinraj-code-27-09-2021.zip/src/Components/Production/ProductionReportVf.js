import React, { Fragment } from "react";

function ProductionReportVf() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default ProductionReportVf;
