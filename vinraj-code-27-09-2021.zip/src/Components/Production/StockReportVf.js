import React, { Fragment } from "react";

function StockReportVf() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default StockReportVf;
