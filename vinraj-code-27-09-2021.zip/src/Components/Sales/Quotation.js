import React, { Fragment } from "react";

function Quotation() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default Quotation;
