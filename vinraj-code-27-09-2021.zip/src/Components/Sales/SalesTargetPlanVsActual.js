import React, { Fragment } from "react";
import Sidebar from "../Home/Sidebar";

function SalesTargetPlanVsActual() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default SalesTargetPlanVsActual;
