import React, { Fragment } from "react";

function CustomerFeedback() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default CustomerFeedback;
