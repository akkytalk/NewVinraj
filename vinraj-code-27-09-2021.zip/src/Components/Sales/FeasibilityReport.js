import React, { Fragment } from "react";

function FeasibilityReport() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default FeasibilityReport;
