import React, { Fragment } from "react";

function EnquiryForm() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default EnquiryForm;
