import React, { Fragment } from "react";

function BreakdownMaintenance() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default BreakdownMaintenance;
