import React, { Fragment } from "react";

function BreakdownMaintenanceAnalysisRecord() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default BreakdownMaintenanceAnalysisRecord;
