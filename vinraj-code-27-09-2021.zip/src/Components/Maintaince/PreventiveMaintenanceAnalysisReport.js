import React, { Fragment } from "react";

function PreventiveMaintenanceAnalysisReport() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default PreventiveMaintenanceAnalysisReport;
