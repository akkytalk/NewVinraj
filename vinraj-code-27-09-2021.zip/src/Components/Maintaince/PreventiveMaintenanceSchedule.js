import React, { Fragment } from "react";

function PreventiveMaintenanceSchedule() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default PreventiveMaintenanceSchedule;
