import React, { Fragment } from "react";

function EquipmentValidationReport() {
  return (
    <Fragment>
      <div>EQUIPMENT VALIDATION REPORT</div>
    </Fragment>
  );
}

export default EquipmentValidationReport;
