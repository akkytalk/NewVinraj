import React, { Fragment } from "react";

function BreakdownMaintenanceRecord() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default BreakdownMaintenanceRecord;
