import React, { Fragment } from "react";

function MachineryAndEquipmentMmanualList() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default MachineryAndEquipmentMmanualList;
