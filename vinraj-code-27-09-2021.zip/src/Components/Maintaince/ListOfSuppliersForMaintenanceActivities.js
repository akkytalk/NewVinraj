import React, { Fragment } from "react";

function ListOfSuppliersForMaintenanceActivities() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default ListOfSuppliersForMaintenanceActivities;
