import React, { Fragment } from "react";

function PreventiveMaintenanceRecord() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default PreventiveMaintenanceRecord;
