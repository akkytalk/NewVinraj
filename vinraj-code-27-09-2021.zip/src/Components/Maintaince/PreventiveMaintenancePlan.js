import React, { Fragment } from "react";

function PreventiveMaintenancePlan() {
  return (
    <Fragment>
      <div>PreventiveMaintenancePlan</div>
    </Fragment>
  );
}

export default PreventiveMaintenancePlan;
