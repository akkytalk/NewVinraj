import React, { Fragment } from "react";
import Sidebar from "../Home/Sidebar";

function ProductionMa() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default ProductionMa;
