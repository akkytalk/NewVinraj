import React, { Fragment } from "react";
import Sidebar from "../Home/Sidebar";

function Capa() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default Capa;
