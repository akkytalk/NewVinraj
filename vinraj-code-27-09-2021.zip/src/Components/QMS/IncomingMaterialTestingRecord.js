import React, { Fragment } from "react";
import Sidebar from "../Home/Sidebar";

function IncomingMaterialTestingRecord() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default IncomingMaterialTestingRecord;
