import React, { Fragment } from "react";
import Sidebar from "../Home/Sidebar";

function CustomerComplaintRecord() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default CustomerComplaintRecord;
