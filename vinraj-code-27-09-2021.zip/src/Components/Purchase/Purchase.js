import React, { Fragment } from "react";

import Req2 from "./Req2";
import {
  Card,
  CardHeader,
  CardBody,
  Row,
  Col,
  Button,
  Modal,
  ModalBody,
  ModalHeader,
} from "reactstrap";
const Purchase = () => {
  return (
    <Fragment>
     <Card>
     <CardHeader className="bg-warning text-white card-header-sticky d-flex ">
     <strong>Purchase Requisition</strong>
     <Req2 />
     </CardHeader>

      <CardBody>
          <table
            className="table table-sm text-center"
            style={{ fontSize: "12px" }}
          >
            <thead className="table-sticky">
              <tr>
                {/* <th>ID</th> */}
                <th scope="col">Dept</th>
                <th scope="col">Title</th>
                <th scope="col">Rev no</th>
                <th scope="col">Rev Date</th>
                <th scope="col">Date</th>
                <th scope="col">Ref no</th>

                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {/* {props.subcats?.length > 0 ? (
                props.subcats?.map((user, ind) => (
                  <tr key={user.id}>
                    <td>{ind + 1}</td>
                    <td>{user.name}</td>
                    <td>{user?.major_category?.name}</td>

                    <td className="">
                      <Button
                        className="btn-warning p-1"
                        onClick={() => {
                          props.onEditSubcatsRow(
                            data,
                            user.id,
                            editing,
                            setEditing,
                            currentUser,
                            setCurrentUser
                          );
                          toggle();
                        }}
                      >
                        <i className="fa fa-edit" aria-hidden="true"></i>
                      </Button>

                      <Button
                        className="btn-danger ml-3 p-1"
                        onClick={() => {
                          if (
                            window.confirm(
                              "Are you sure you wish to delete this Sub Category?"
                            )
                          )
                            props.onDeleteSubcats(data, user.id);
                        }}
                      >
                        <i
                          className="fa fa-trash-alt "
                          value={user.id}
                          aria-hidden="true"
                        ></i>
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={3}>No users</td>
                </tr>
              )} */}
            </tbody>
          </table>
        </CardBody>
     
     </Card>
    </Fragment>
  );
};

export default Purchase;
