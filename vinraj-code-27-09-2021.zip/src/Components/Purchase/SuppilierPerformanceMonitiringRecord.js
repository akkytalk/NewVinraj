import React, { Fragment } from "react";

function SuppilierPerformanceMonitiringRecord() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default SuppilierPerformanceMonitiringRecord;
