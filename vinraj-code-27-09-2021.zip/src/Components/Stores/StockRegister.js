import React, { Fragment } from "react";

function StockRegister() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default StockRegister;
