import React, { Fragment } from "react";

function ListOfShelfLifeOfItems() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default ListOfShelfLifeOfItems;
