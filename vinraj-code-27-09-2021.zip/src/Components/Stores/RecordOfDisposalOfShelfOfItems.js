import React, { Fragment } from "react";

function RecordOfDisposalOfShelfOfItems() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default RecordOfDisposalOfShelfOfItems;
