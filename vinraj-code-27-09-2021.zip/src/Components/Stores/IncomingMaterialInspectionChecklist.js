import React, { Fragment } from "react";

function IncomingMaterialInspectionChecklist() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default IncomingMaterialInspectionChecklist;
