import React, { Fragment } from "react";

function PurchaseRequisition() {
  return (
    <Fragment>
      <div></div>
    </Fragment>
  );
}

export default PurchaseRequisition;
