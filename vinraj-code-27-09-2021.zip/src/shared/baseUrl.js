export const baseUrl = "https://uditsolutions.in/vinrajbackend/public/api/";
